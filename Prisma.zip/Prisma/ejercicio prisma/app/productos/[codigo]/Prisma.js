//Configuracion de prisma
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()
export default prisma



//listado de registros

import prisma from '../../../lib/prisma'

export default async function handler(req, res) {
  if (req.method === 'GET') {
    const products = await prisma.product.findMany()
    res.status(200).json(products)
  } else {
    res.status(405).json({ message: 'Only GET requests allowed' })
  }
}


//Busqueda por codigo

import prisma from '../../../lib/prisma'

export default async function handler(req, res) {
  const { code } = req.query

  if (req.method === 'GET') {
    const product = await prisma.product.findUnique({
      where: { code },
    })
    if (product) {
      res.status(200).json(product)
    } else {
      res.status(404).json({ message: 'Product not found' })
    }
  }
}


//Creacion de registros

import prisma from '../../../lib/prisma'

export default async function handler(req, res) {
  if (req.method === 'POST') {
    const { code, name, description, price } = req.body
    try {
      const newProduct = await prisma.product.create({
        data: { code, name, description, price: parseFloat(price) },
      })
      res.status(201).json(newProduct)
    } catch (error) {
      res.status(400).json({ message: 'Error creating product' })
    }
  } else {
    res.status(405).json({ message: 'Only POST requests allowed' })
  }
}

//Actualizacion de registros 

import prisma from '../../../lib/prisma'

export default async function handler(req, res) {
  const { code } = req.query
  const { name, description, price } = req.body

  if (req.method === 'PUT') {
    try {
      const updatedProduct = await prisma.product.update({
        where: { code },
        data: { name, description, price: parseFloat(price) },
      })
      res.status(200).json(updatedProduct)
    } catch (error) {
      res.status(404).json({ message: 'Error updating product or product not found' })
    }
  }
}



//listado de productos
// pages/products.js
import { useState, useEffect } from 'react'

export default function ProductsList() {
  const [products, setProducts] = useState([])

  useEffect(() => {
    fetch('/api/products')
      .then((res) => res.json())
      .then((data) => setProducts(data))
  }, [])

  return (
    <div>
      <h1>Product List</h1>
      <ul>
        {products.map((product) => (
          <li key={product.id}>{product.name} - ${product.price}</li>
        ))}
      </ul>
    </div>
  )
}

//creacion de productos
// components/ProductForm.js
import { useState } from 'react'

export default function ProductForm() {
  const [formData, setFormData] = useState({ code: '', name: '', description: '', price: '' })

  const handleSubmit = async (e) => {
    e.preventDefault()
    await fetch('/api/products/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData),
    })
  }

  return (
    <form onSubmit={handleSubmit}>
      <input placeholder="Code" onChange={(e) => setFormData({ ...formData, code: e.target.value })} />
      <input placeholder="Name" onChange={(e) => setFormData({ ...formData, name: e.target.value })} />
      <input placeholder="Description" onChange={(e) => setFormData({ ...formData, description: e.target.value })} />
      <input placeholder="Price" type="number" onChange={(e) => setFormData({ ...formData, price: e.target.value })} />
      <button type="submit">Create Product</button>
    </form>
  )
}


//Conexion pagina principal
// pages/index.js
import ProductsList from './products'
import ProductForm from '../components/ProductForm'

export default function Home() {
  return (
    <div>
      <h1>Product Management</h1>
      <ProductForm />
      <ProductsList />
    </div>
  )
}

